package Main;

public class Cama {

}
