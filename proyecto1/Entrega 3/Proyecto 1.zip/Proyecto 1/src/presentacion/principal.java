package presentacion;

public class principal {
	private Hotel hotel;
	

}
